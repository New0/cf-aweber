This repository is for development of [Aweber for Caldera Forms](https://calderawp.com/downloads/aweber-caldera-forms/) which is a commerical plugin. If you need support for this plugin, use [open a support ticket](https://CalderaWP.com/support). 

if you download this respository's built zip file, it will not work. You must use Composer to build the plugin, or buy a copy from our site.

Copyright 2016 Josh Pollock for CalderaWP LLC. License under the terms of the GPL v2 or later.
